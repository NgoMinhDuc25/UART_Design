######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Wed May 13 16:15:44 +07 2026

# This file contains the Genus script for design:uart_top

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {. ../sky130_scl_9T_0.1.2/sky130_scl_9T/lib/ }
set_db -quiet design_mode_process 140.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 23 0.0 28.0} {to_generic 6 30 6 34} {first_condense 3 34 3 38} {PBS_Generic_Opt-Post 12 35 10.998049000000002 38.998049} {{PBS_Generic-Postgen HBO Optimizations} 0 35 0.0 38.998049} {PBS_TechMap-Start 0 39 0.0 40.998013} {{PBS_TechMap-Premap HBO Optimizations} 0 39 0.0 40.998013} {second_condense 2 41 2 43} {reify 4 45 4 47} {global_incr_map 2 47 1 49} {{PBS_Techmap-Global Mapping} 8 47 8.997762999999999 49.995776} {{PBS_TechMap-Datapath Postmap Operations} 3 50 2.0 51.995776} {{PBS_TechMap-Postmap HBO Optimizations} 0 50 0.0 51.995776} {{PBS_TechMap-Postmap Clock Gating} 0 50 0.0 51.995776} {{PBS_TechMap-Postmap Cleanup} 1 51 1.0 52.995776} {PBS_Techmap-Post_MBCI 0 51 0.0 52.995776} {incr_opt 4 57 4 57}  {IOPT_RUNTIME_INIT 0 58 0 57}  {IOPT_RUNTIME_TPS_OPTO 0 58 0 58}  {IOPT_RUNTIME_CRR_AREA_OPTO 5 63 5 63}  {IOPT_RUNTIME_MT_AREA_OPTO 2 65 1 64}  {IOPT_RUNTIME_AREA_RECLAIM_OPTO 0 65 0 64} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ngominhduc.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet super_thread_servers localhost
set_db -quiet max_cpus_per_server 0
set_db -quiet script_search_path {. ./scripts/ }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet hdl_track_filename_row_col true
set_db -quiet lp_insert_discrete_clock_gating_logic true
set_db -quiet lp_clock_gating_prefix pow_opt
set_db -quiet design_power_effort high
set_db -quiet flow_metrics_snapshot_uuid 066f1dbc-6e2d-4fa6-bfa7-85a812c22def
set_db -quiet hinst:uart_top/rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/uart_rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/uart_tx_inst .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
