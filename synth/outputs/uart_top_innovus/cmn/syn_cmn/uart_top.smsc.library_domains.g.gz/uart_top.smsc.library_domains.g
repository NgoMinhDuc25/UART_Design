::legacy::set_attribute -quiet library_domain library_domain:slow design:uart_top
