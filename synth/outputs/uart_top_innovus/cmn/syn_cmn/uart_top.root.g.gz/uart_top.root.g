######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Mon May 11 22:27:35 +07 2026

# This file contains the Genus script for design:uart_top

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {. ../sky130_scl_9T_0.1.2/sky130_scl_9T/lib/ }
set_db -quiet design_mode_process 140.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 23 0.0 27.0} {to_generic 8 31 7 34} {first_condense 4 35 3 39} {PBS_Generic_Opt-Post 13 36 12.999955 39.999955} {{PBS_Generic-Postgen HBO Optimizations} 0 36 0.0 39.999955} {PBS_TechMap-Start 0 39 0.0 40.999955} {{PBS_TechMap-Premap HBO Optimizations} 0 39 0.0 40.999955} {second_condense 2 41 1 43} {reify 4 45 4 47} {global_incr_map 1 46 0 48} {{PBS_Techmap-Global Mapping} 7 46 6.996476000000001 47.996431} {{PBS_TechMap-Datapath Postmap Operations} 3 49 3.0 50.996431} {{PBS_TechMap-Postmap HBO Optimizations} 0 49 0.0 50.996431} {{PBS_TechMap-Postmap Clock Gating} 0 49 0.0 50.996431} {{PBS_TechMap-Postmap Cleanup} 0 49 0.0 50.996431} {PBS_Techmap-Post_MBCI 0 49 0.0 50.996431} {incr_opt 4 56 4 56} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ngominhduc.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet super_thread_servers localhost
set_db -quiet max_cpus_per_server 0
set_db -quiet script_search_path {. ./scripts/ }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet flow_metrics_snapshot_uuid 42407848-10bc-4f9b-8d7c-2cc83bdd7e9a
set_db -quiet hinst:uart_top/rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/uart_rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/uart_tx_inst .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
