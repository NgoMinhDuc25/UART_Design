######################################################################

# Created by Genus(TM) Synthesis Solution 23.10-p004_1 on Wed May 13 17:15:23 +07 2026

# This file contains the Genus script for design:uart_top

######################################################################

set_db -quiet information_level 7
set_db -quiet init_lib_search_path {. ../sky130_scl_9T_0.1.2/sky130_scl_9T/lib/ }
set_db -quiet design_mode_process 140.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet lp_insert_clock_gating true
set_db -quiet runtime_by_stage {{PBS_Generic-Start 0 27 0.0 31.0} {to_generic 6 34 6 38} {first_condense 2 37 2 41} {PBS_Generic_Opt-Post 11 38 10.999799000000003 41.999799} {{PBS_Generic-Postgen HBO Optimizations} 0 38 0.0 41.999799} {PBS_TechMap-Start 0 42 0.0 43.99977} {{PBS_TechMap-Premap HBO Optimizations} 0 42 0.0 43.99977} {second_condense 2 44 1 45} {reify 4 48 4 49} {global_incr_map 2 50 2 52} {{PBS_Techmap-Global Mapping} 8 50 7.9997630000000015 51.999533} {{PBS_TechMap-Datapath Postmap Operations} 3 53 2.0 53.999533} {{PBS_TechMap-Postmap HBO Optimizations} 0 53 1.0 54.999533} {{PBS_TechMap-Postmap Clock Gating} 0 53 0.0 54.999533} {{PBS_TechMap-Postmap Cleanup} 0 53 0.0 54.999533} {PBS_Techmap-Post_MBCI 0 53 0.0 54.999533} {incr_opt 6 62 5 61}  {IOPT_RUNTIME_INIT 0 62 0 61}  {IOPT_RUNTIME_TPS_OPTO 0 62 0 61}  {IOPT_RUNTIME_CRR_AREA_OPTO 1 63 1 63}  {IOPT_RUNTIME_MT_AREA_OPTO 2 65 1 64}  {IOPT_RUNTIME_AREA_RECLAIM_OPTO 1 66 0 65} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet timing_report_enable_common_header false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_ngominhduc.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet super_thread_servers localhost
set_db -quiet max_cpus_per_server 0
set_db -quiet script_search_path {. ./scripts/ }
set_db -quiet auto_ungroup none
set_db -quiet use_area_from_lef true
set_db -quiet hdl_track_filename_row_col true
set_db -quiet lp_insert_discrete_clock_gating_logic true
set_db -quiet lp_clock_gating_prefix pow_opt
set_db -quiet design_power_effort high
set_db -quiet flow_metrics_snapshot_uuid 4826b5e8-f449-48a3-8c42-edf06f3761a8
set_db -quiet hinst:uart_top/rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/rx_inst/uart_rx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/bau_gen_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/memory_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/read_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/state_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/fifo_inst/write_pointer_inst .hdl_instantiated true
set_db -quiet hinst:uart_top/tx_inst/uart_tx_inst .hdl_instantiated true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
